# Zone Builder UI Specification

## 1. Product goal

Let players define reusable groups of assets and combine those groups into custom zoning presets, while keeping the game world visible and minimizing UI obstruction.

The UI is a management tool, not a replacement for the entire game screen or a giant image gallery.

## 2. Core domain hierarchy

```text
Zone
└── one or more Collections
    └── one or more Assets
```

- **Zone:** a player-defined zoning preset that gathers assets from its attached collections.
- **Collection:** a reusable, named group of assets.
- **Asset:** a game asset that can be included in a collection.

A collection can be reused by multiple zones unless the existing backend explicitly forbids it. The UI must not assume that a collection belongs to only one zone.

## 3. Primary layout

### Compact floating panel

- Anchor to a side of the game viewport, preferably using the placement behavior already established by the mod or host UI.
- Default to a narrow, vertically oriented panel. The city should remain visible around it.
- Include a compact title bar with the mod name and a close/collapse control if supported by the existing integration.
- Use three primary navigation tabs: **Zones**, **Collections**, and **Assets**.
- Provide a search field near the top of the active list.
- Place a clear primary action near the list header: `+ New Zone`, `+ New Collection`, or `+ Add Assets`, depending on the active view.
- Use dense, readable rows rather than large cards.
- Show thumbnails only when the game provides a supported image; thumbnails are small and secondary to names.
- Keep row actions aligned consistently at the trailing edge.

### Detail area

Selecting a zone or collection opens its details in the panel (or a compact adjacent pane if the existing UI framework supports it without excessive width).

Zone details:
- Name
- Collection count
- List of attached collections
- `Edit` and `Delete` actions
- `Add Collection` action
- Per-collection `Remove from Zone` action

Collection details:
- Name
- Asset count
- List of member assets
- `Edit` and `Delete` actions
- `Add Assets` action
- Per-asset `Remove from Collection` action

Do not duplicate a complete asset gallery in the zone details view. Show attached collection rows and counts; the collection itself owns the asset list.

## 4. Navigation and creation flexibility

Both workflows must be supported:

### Workflow A — Zone first
1. Create a zone.
2. Open the zone details.
3. Add an existing collection, or create a new collection and attach it.
4. Edit collection membership later as needed.

### Workflow B — Collections first
1. Create one or more collections.
2. Add assets to each collection.
3. Create a zone.
4. Attach one or more existing collections.

Avoid a wizard that forces one workflow. All entities remain independently accessible from the three tabs.

## 5. Visual direction

- Dark, restrained, game-appropriate palette; derive exact colors from existing mod/game tokens where available.
- Compact spacing and clear contrast.
- Small type is acceptable for secondary metadata, but primary labels and row actions must remain legible at common gameplay resolutions.
- Avoid oversized hero images, empty decorative areas, or high-density grids of thumbnails.
- Use a consistent icon-only treatment for row-level Edit and Delete actions, with accessible labels/tooltips if supported.
- Make destructive actions visually distinct, but do not rely on color alone.
- Selection state must be obvious without dominating the panel.
- Avoid hover-only access to essential actions; controller/touch/keyboard support depends on the mod's input model, so ensure actions remain reachable without hover where feasible.

## 6. Common list row

Each Zone or Collection row should contain:
- Selection target: name and useful count metadata.
- Optional small icon/thumbnail if supported.
- Edit action.
- Delete action.

Recommended structure:

```text
[small icon]  Harborview Suburbs       2 collections   [edit] [delete]
```

Collection row:

```text
[small icon]  Mid Century Modern       24 assets       [edit] [delete]
```

Asset row:

```text
[small thumbnail]  Row House 02        Residential     [remove]
```

Asset edit should only be shown if the backend supports editing asset metadata. Otherwise the meaningful operation is remove-from-collection.

## 7. Search and filtering

- Search applies to the active list and should preserve the selected tab.
- The asset picker needs search and any useful filters supported by the existing asset index.
- Do not fabricate filter categories. Discover them from the real asset metadata/backend.
- Clearing search returns to the full current list.
- Empty search results should offer a clear reset action.

## 8. Feedback states

Every mutating operation should have a clear outcome:
- Pending/loading when an operation can take noticeable time.
- Success feedback that does not block play.
- Inline validation for invalid or duplicate names if applicable.
- Recoverable error feedback if the backend rejects an operation.
- Keep the dialog open when a save fails so user input is not lost.
- Prevent accidental duplicate submissions while a mutation is pending.

## 9. Accessibility and usability

- Tooltips or accessible labels for icon-only controls.
- Adequate hit targets for in-game mouse use.
- Visible focus/selection states where supported by Cohtml.
- Do not communicate delete/selection/error using color alone.
- Use explicit labels in confirmation dialogs.
- Avoid excessive animation and large transitions that distract during gameplay.
