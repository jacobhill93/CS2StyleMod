# Interaction Rules and Entity Semantics

## 1. Create and edit

| Entity | Create | Edit | Delete |
|---|---|---|---|
| Zone | Name; optionally attach collections | Prefilled form; rename and adjust attached collections | Delete only the zone |
| Collection | Name; optionally choose initial assets | Prefilled form; rename and adjust asset membership | Delete collection and detach its zone references |
| Asset | Not created by this mod | Only expose metadata edit if supported by backend | Never delete the underlying game asset from this UI |

Treat create and edit as the same form component with different mode, initial data, title, and submit label.

## 2. Distinguish entity deletion from relationship removal

This is the most important safety rule in the UI.

- **Delete Zone:** deletes the selected zone only. Collections remain available.
- **Remove Collection from Zone:** deletes the relationship between that zone and collection. The collection remains available and can be attached to other zones.
- **Delete Collection:** deletes the collection and removes its references from every zone that contains it. Game assets remain untouched.
- **Remove Asset from Collection:** deletes the relationship between collection and asset. The game asset remains untouched.

Never label relationship removal as `Delete`. Use contextual labels like `Remove from Zone` and `Remove from Collection`.

## 3. Confirmation policy

- Confirm permanent deletion of a zone or collection.
- Do not require a confirmation dialog for removing one item from a collection/zone unless project conventions or backend behavior make it unusually consequential. A reversible toast/undo affordance is a possible enhancement if supported.
- Confirmation copy names the affected entity and explains what remains.
- Disable repeated confirmation while the mutation is pending.
- Close the confirmation only after success; on failure show an error and allow retry.

## 4. Selection and navigation

- Clicking a list row selects it and opens details.
- Edit and Delete are independent row actions.
- After deleting the selected item, select the next sensible item if possible; otherwise return to the list's empty state.
- Changing tabs should not silently discard unsaved form input. Warn or prevent navigation if a form has dirty changes.
- After a successful edit, keep the same entity selected and refresh its displayed name/counts.
- After adding/removing membership, update counts and dependent views from backend-confirmed state.

## 5. Search and filtering

- Search should be scoped to the active entity list.
- Asset picker search is scoped to the full asset catalog, with supported metadata filters.
- Search and filters should not mutate membership until the user confirms their selection.
- Do not include assets already in the collection as addable duplicates unless the data model explicitly allows duplicates.

## 6. Errors and asynchronous mutations

- Use the existing backend bridge and its actual success/error contract.
- Do not optimistically claim a save/delete succeeded before confirmation from the backend.
- If a mutation fails, preserve user input and selected context.
- Prevent duplicate submissions while pending.
- Keep error messages concise and actionable.

## 7. Accessibility and input

- Every icon-only action must have a title/accessible label.
- Do not make Edit/Delete available only on hover.
- Confirm dialogs must clearly distinguish Cancel and destructive confirmation.
- Use existing Cohtml-supported input, focus, and keyboard conventions; verify in the game.
