# Wireframes and UI States

These are structural wireframes, not pixel-perfect specifications. Keep the compact top-panel direction from the approved concept.

## A. Main panel — Zones tab

```text
┌─────────────────────────────────────────────┐
│ ZONE BUILDER                         [—] [×]│
├─────────────────────────────────────────────┤
│ [ Zones ] [ Collections ] [ Assets ]        │
├─────────────────────────────────────────────┤
│ Zones                         [+ New Zone]  │
│ [ Search zones...                         ] │
├─────────────────────────────────────────────┤
│ ▸ Harborview Suburbs      2 collections     │
│                              [edit] [delete]│
│   Mid Century Modern       24 assets        │
│                              [edit] [delete]│
│   Row Houses               12 assets        │
│                              [edit] [delete]│
└─────────────────────────────────────────────┘
```

Selection behavior: selecting a zone displays its details. The row's edit/delete controls must not accidentally trigger selection if the UI framework allows event propagation control.

## B. Zone detail / selected zone

```text
┌─────────────────────────────────────────────┐
│ Harborview Suburbs            [Edit] [Delete]│
│ 2 collections                               │
├─────────────────────────────────────────────┤
│ COLLECTIONS                  [+ Add]        │
│ ┌─────────────────────────────────────────┐ │
│ │ Mid Century Modern   24 assets [edit]   │ │
│ │                                 [remove]│ │
│ └─────────────────────────────────────────┘ │
│ ┌─────────────────────────────────────────┐ │
│ │ Row Houses           12 assets [edit]   │ │
│ │                                 [remove]│ │
│ └─────────────────────────────────────────┘ │
│                                             │
│ [ + Create Collection and Add to Zone ]     │
└─────────────────────────────────────────────┘
```

The collection's Edit action edits the collection itself. Remove detaches it from this zone only.

## C. Collections tab

```text
┌─────────────────────────────────────────────┐
│ [ Zones ] [ Collections ] [ Assets ]        │
├─────────────────────────────────────────────┤
│ Collections               [+ New Collection]│
│ [ Search collections...                   ] │
├─────────────────────────────────────────────┤
│ Mid Century Modern             24 assets    │
│                                  [edit][del]│
│ Row Houses                     12 assets    │
│                                  [edit][del]│
│ Harbor Brick Low-Rise            8 assets   │
│                                  [edit][del]│
└─────────────────────────────────────────────┘
```

Selecting a collection opens its asset membership details.

## D. Collection detail / edit membership

```text
┌─────────────────────────────────────────────┐
│ Mid Century Modern              [Edit][Delete]│
│ 24 assets                                   │
├─────────────────────────────────────────────┤
│ [ Search assets in collection...          ] │
│                             [+ Add Assets]  │
├─────────────────────────────────────────────┤
│ [tiny] Modern House A      Residential [−]  │
│ [tiny] Modern House B      Residential [−]  │
│ [tiny] Modern Duplex       Residential [−]  │
└─────────────────────────────────────────────┘
```

The minus/remove action removes the asset from this collection. It does not delete the game asset.

## E. Asset picker dialog

```text
┌─────────────────────────────────────────────────────┐
│ Add assets to: Mid Century Modern             [×]   │
├─────────────────────────────────────────────────────┤
│ [ Search all assets...                            ] │
│ [Category ▾] [Other supported filters ▾]             │
├─────────────────────────────────────────────────────┤
│ [ ] [tiny] Modern House A      Residential           │
│ [✓] [tiny] Modern House B      Residential           │
│ [ ] [tiny] Modern Duplex       Residential            │
│ ...                                                 │
├─────────────────────────────────────────────────────┤
│ 3 selected                         [Cancel] [Add (3)]│
└─────────────────────────────────────────────────────┘
```

- Keep the dialog bounded; it should not occupy the full screen by default.
- Selected count and confirmation action stay visible.
- If the asset list is large, use the most efficient supported list virtualization/paging strategy.
- Existing members should be marked as already included and should not be added twice unless duplicate membership is an intentional backend feature.

## F. Create / Edit Zone dialog

```text
┌─────────────────────────────────────────────┐
│ Create Zone                            [×]  │
├─────────────────────────────────────────────┤
│ Name                                        │
│ [ Harborview Suburbs                     ]  │
│                                             │
│ Collections                                 │
│ [✓] Mid Century Modern                      │
│ [ ] Row Houses                              │
│ [+ Create a collection]                     │
│                                             │
│                         [Cancel] [Create]   │
└─────────────────────────────────────────────┘
```

Edit mode uses the same form, prefilled with current values, with title `Edit Zone` and primary action `Save`. If the backend supports attaching collections after creation as a separate operation, the dialog may show current membership and submit changes through the real supported operations.

## G. Create / Edit Collection dialog

```text
┌─────────────────────────────────────────────┐
│ Create Collection                      [×]  │
├─────────────────────────────────────────────┤
│ Name                                        │
│ [ Mid Century Modern                     ]  │
│                                             │
│ Assets                                      │
│ [ Choose Assets… ]  (24 selected)           │
│                                             │
│                         [Cancel] [Create]   │
└─────────────────────────────────────────────┘
```

The collection form should not try to render the entire asset catalog inline. `Choose Assets…` opens the bounded asset picker.

## H. Delete confirmation

```text
┌─────────────────────────────────────────────┐
│ Delete “Mid Century Modern”?                │
│                                             │
│ This removes the collection and detaches it │
│ from any zones. The game assets themselves │
│ will not be deleted.                        │
│                                             │
│                         [Cancel] [Delete]   │
└─────────────────────────────────────────────┘
```

Use entity-specific copy. For a zone deletion, say the zone will be deleted while its collections remain. For detaching a collection from a zone, do not call the action Delete; use `Remove from Zone`.

## I. Empty states

### No zones
```text
No zones yet
Create a zone and combine collections to define which assets it can use.
[+ Create Zone]
```

### No collections
```text
No collections yet
Create a reusable group of assets. You can attach it to a zone later.
[+ Create Collection]
```

### Empty collection
```text
This collection has no assets yet
Add assets to make the collection usable in a zone.
[+ Add Assets]
```

### Empty zone
```text
This zone has no collections yet
Add an existing collection or create one for this zone.
[+ Add Collection]  [+ Create Collection]
```

### No search results
```text
No matches found
Try a different search or clear the current filters.
[Clear Search]
```

## J. Loading, error, and validation

- Loading list: show a compact progress state or placeholder rows, not a full-screen blocker.
- Save error: keep form values and show an inline error.
- Name validation: show a concise message next to the name field; do not clear the field.
- Delete error: close nothing until the backend confirms success; keep enough context to retry.
- Empty asset source: explain that the asset catalog could not be loaded and provide retry if supported.
