# Cohtml Integration Checklist for the Coding Agent

This checklist intentionally avoids assuming how the current mod is structured. Inspect the repository before implementing.

## 1. Repository reconnaissance

- [ ] Identify the current mod entry point and lifecycle for creating/destroying the Cohtml view.
- [ ] Locate existing UI HTML/JS/CSS or CSS Modules/SCSS setup.
- [ ] Identify the current Cohtml version and the actual capabilities exposed by the host.
- [ ] Find the C# or native-to-UI bridge and document its actual message/event contracts.
- [ ] Find current domain models for zones, collections, and assets.
- [ ] Find persistence/serialization code and existing validation rules.
- [ ] Confirm supported image/thumbnail data and asset metadata.
- [ ] Reuse established project conventions; avoid introducing a new framework unless the repository already uses it.

## 2. UI component seams

Suggested conceptual components (map these to the existing architecture):

- `ZoneBuilderPanel`: shell, title bar, tabs, panel open/collapsed state.
- `EntityList`: searchable list for the active entity type.
- `EntityRow`: selection plus trailing action controls.
- `ZoneDetails`: collection memberships for one zone.
- `CollectionDetails`: asset memberships for one collection.
- `ZoneFormDialog`: shared create/edit zone form.
- `CollectionFormDialog`: shared create/edit collection form.
- `AssetPickerDialog`: searchable catalog and multi-select.
- `ConfirmDeleteDialog`: entity-aware delete confirmation.
- `EmptyState`, `InlineError`, `PendingState`, `Toast` (or equivalents): feedback primitives.

These are conceptual seams, not mandates to create one file per component.

## 3. State model

Keep view state separate from authoritative backend data.

View state examples:
- Active tab (`zones`, `collections`, `assets`)
- Selected zone ID
- Selected collection ID
- Search query per active view
- Active dialog and target entity ID
- Draft form values
- Dirty form state
- Pending operation
- Inline validation/error state

Authoritative state should come from the existing backend/model layer. Avoid maintaining a second, divergent source of truth in UI-only state.

Prefer stable IDs over list indexes or names for entity selection and mutations.

## 4. Suggested UI event contract

Treat these as **semantic actions**, not existing API names. The coding agent must map them to real bridge methods and rename them to match repository conventions.

- `requestZones`
- `requestCollections`
- `requestAssets` (with supported search/filter/page inputs)
- `createZone`
- `updateZone`
- `deleteZone`
- `createCollection`
- `updateCollection`
- `deleteCollection`
- `attachCollectionToZone`
- `detachCollectionFromZone`
- `addAssetsToCollection`
- `removeAssetFromCollection`

For every action, establish:
- Input schema and stable entity IDs
- Whether it is synchronous or asynchronous
- Success payload or refresh mechanism
- Error representation
- Whether the UI should reload all data or update a scoped list

Do not copy these names into runtime code until confirmed against the real bridge.

## 5. Cohtml-specific verification

- [ ] Confirm how HTML is loaded into `cohtml::View`/the actual wrapper used by this mod.
- [ ] Verify which JavaScript and CSS features are supported by the shipped runtime.
- [ ] Verify module/bundler support before using imports, modern syntax, or CSS Modules.
- [ ] Verify how C#-to-JavaScript and JavaScript-to-C# calls are exposed.
- [ ] Verify event subscription/unsubscription to prevent duplicate handlers after view reloads.
- [ ] Verify game input focus, keyboard navigation, mouse capture, and click propagation.
- [ ] Verify panel scaling at common resolutions and UI scale settings.
- [ ] Verify coexistence with vanilla UI, panel anchoring, z-order, and close/collapse behavior.
- [ ] Verify asset images are available and performant; gracefully handle missing images.
- [ ] Verify list rendering performance for large asset catalogs.
- [ ] Avoid relying on browser APIs that are not guaranteed by the embedded Cohtml runtime.

## 6. Implementation and QA order

1. Shell and tab navigation using mock data.
2. Zone/collection list and selected-detail states.
3. Create/edit dialogs and validation.
4. Asset picker search, filtering, selection, and membership updates.
5. Relationship removal and entity deletion confirmations.
6. Backend bridge integration.
7. Loading/error/pending states.
8. In-game verification and cleanup.

## 7. Definition of done

- [ ] Both zone-first and collection-first workflows work.
- [ ] Every zone and collection can be edited repeatedly.
- [ ] Every zone and collection has an explicit delete action.
- [ ] Assets can be added to/removed from collections without deleting game assets.
- [ ] Collections can be attached to/detached from zones without accidental collection deletion.
- [ ] Empty, loading, validation, and error states are covered.
- [ ] No UI operation reports success before backend confirmation.
- [ ] The panel remains compact and gameplay-friendly.
- [ ] No backend API or Cohtml capability has been assumed without checking the repository/runtime.
