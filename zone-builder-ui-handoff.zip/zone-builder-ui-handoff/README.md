# Zone Builder — UI Design Handoff

This folder contains the implementation-oriented UI specification for the **Zone Builder** Cities: Skylines II mod.

## Purpose

Give a coding agent a stable product/design contract before it integrates the UI with the mod's existing backend.

## Start here

1. Read [`docs/ui-spec.md`](docs/ui-spec.md) for the hierarchy, layout, components, and visual rules.
2. Read [`docs/wireframes.md`](docs/wireframes.md) for the compact panel and dialog states.
3. Read [`docs/interaction-rules.md`](docs/interaction-rules.md) for create/edit/delete behavior and reference semantics.
4. Read [`docs/cohtml-integration-checklist.md`](docs/cohtml-integration-checklist.md) before writing integration code.

## Important boundaries

- This is a **design and behavior specification**, not a claim about the current repository's APIs.
- Do not invent backend methods, data models, asset identifiers, or Cohtml bindings. Inspect the existing mod code and adapt the UI layer to its real contracts.
- Keep the main panel compact and gameplay-friendly. Do not turn it into a full-screen asset browser by default.
- Preserve the conceptual hierarchy: **Zone → Collections → Assets**.
- The user may start by creating a zone or by creating collections first.
- Zones and collections are expected to be editable repeatedly, not treated as immutable setup steps.

## Suggested implementation sequence

1. Inspect current project structure and identify the Cohtml view lifecycle, entry point, styling conventions, and backend bridge.
2. Implement the shell, navigation, compact rows, selection states, and dialogs with mock data.
3. Wire existing backend operations into create/update/delete and membership changes.
4. Add loading, empty, validation, error, and confirmation states.
5. Verify in-game sizing, input behavior, z-order, and coexistence with vanilla UI.
